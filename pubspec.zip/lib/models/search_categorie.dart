class SearchCategory{
  static final String popular = "Popular";
  static final String upcoming = "Upcoming";
  static final String none="";

}